const blank = () => {
    return <div><p>This is Blank page</p></div>;
};

export default blank;